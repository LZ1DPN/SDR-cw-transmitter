This is the Arduino/Teensy 3.2 script for the VFO and controller for the
Peppermint Bark BITX40 radio.

Bruce MacKinnon KC1FSZ (https://www.qrz.com/db/KC1FSZ)

![Peppermint Bark BITX40](https://s3.amazonaws.com/files.qrz.com/z/kc1fsz/IMG_1597.JPG)

Here's what it looks like talking to Ham Radio Deluxe:

![CAT Interface](https://s3.amazonaws.com/files.qrz.com/z/kc1fsz/IMG_1600.JPG)
